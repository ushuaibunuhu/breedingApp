

const loadProfiles = () => {
    const xhttp = new XMLHttpRequest();

    xhttp.open("GET", "http://localhost:8080/profiles", false);
    xhttp.send();

    const profiles = JSON.parse(xhttp.responseText);

    for (let profile of profiles) {
        const x = `
            <div class="col-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">${profile.name}</h5>

                        <div>Author: ${profile.dname}</div>
                        <div>Publisher: ${profile.cname}</div>
                        <div>Number Of Pages: ${profile.prefex}</div>
                        <div>Author: ${profile.dob}</div>
                        <div>Publisher: ${profile.size}</div>
                        <div>Number Of Pages: ${profile.weight}</div>

                        <hr>

                        <button type="button" class="btn btn-danger">Delete</button>
                        
                    </div>
                </div>
            </div>
        `

        document.getElementById('profiles').innerHTML = document.getElementById('profiles').innerHTML + x;
    }
}

loadProfiles();