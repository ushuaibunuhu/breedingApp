

const loadArranges = () => {
    const xhttp = new XMLHttpRequest();

    xhttp.open("GET", "http://localhost:8080/views/arranges", false);
    xhttp.send();

    const arranges = JSON.parse(xhttp.responseText);

    for (let arrange of arranges) {
        const x = `
            <div class="col-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">${arrange.name}</h5>

                        <div>Author: ${arrange.phone}</div>
                        <div>Publisher: ${arrange.place}</div>
                        <div>Number Of Pages: ${arrange.note}</div>

                        <hr>

                        <button type="button" class="btn btn-danger">Delete</button>
                        
                    </div>
                </div>
            </div>
        `

        document.getElementById('arranges').innerHTML = document.getElementById('arranges').innerHTML + x;
    }
}

loadArranges();