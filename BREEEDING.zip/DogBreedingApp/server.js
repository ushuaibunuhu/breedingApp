if  (process.env.NODE_ENV !== 'production') {
    require('dotenv').config()
}

const express =  require('express')
const app = express()
var mysql = require('mysql')
var bodyParser = require('body-parser')
var path = require('path')
const bcrypt = require('bcryptjs')
const passport = require('passport')
const flash = require('express-flash')
const session = require('express-session')
const methodOverride = require('method-override')
var cors = require('cors');

const port = 8080;



const initializePassport = require('./passport-config.js')
initializePassport(
    passport, 
    email => users.find( user => user.email === email),
    id => users.find(user => user.id === id)
)

const users = []


app.use(cors());
let arranges = []

const profiles = []

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.post('/arrange', (req, res) => {

    const arrange = req.body;

    // Output the mate to the console for debugging
    console.log(arrange);
    arranges.push(arrange);

    res.send('Mate is added to the database');
});

app.get('/arranges', (req, res) => {
    res.json(arranges);
});

app.post('/profile', (req, res) => {

    const profile = req.body;

    // Output the mate to the console for debugging
    console.log(profile);
    profiles.push(profile);

    res.send('Mate is added to the database');
});

app.get('/profiles', (req, res) => {
    res.json(profiles);
});


app.set('view-engine', 'ejs')
app.use(express.urlencoded({ extended: false}))
app.use(flash())
app.use(session({
    secret: process.env.SESSION_SECRET, 
    resave: false,
    saveUninitialized: false
}))

app.use(passport.initialize())
app.use(passport.session())
app.use(methodOverride('_method'))

app.get('/', (req, res) => {
    res.render('index.ejs')
})

app.get('/profile', (req, res) => {
    res.render('profile.ejs', { 
        name: req.user.name})
})




app.get('/bitches', (req, res) => {
    res.render('bitches.ejs', { name: req.user.name})
})

app.get('/dashboard', checkAuthenticated, (req, res) => {
    res.render('dashboard.ejs', { name: req.user.name})
})

app.get('/login', checkNotAuthenticated, (req, res) => {
    res.render('login.ejs')
})
 
app.post('/login', checkNotAuthenticated,  passport.authenticate( 'local', {
    successRedirect: '/dashboard',
    failureRedirect: '/login',
    failureFlash: true
}))
 


app.get('/register', checkNotAuthenticated, (req, res) => {
    res.render('register.ejs')
})

app.post('/register', checkNotAuthenticated, async (req, res) => {
    try{
        const hashedPassword = await bcrypt.hash(req.body.password, 10)
        users.push({
            id: Date.now().toString(),
            name: req.body.name,
            email: req.body.email,
            password: hashedPassword
        })
        res.redirect('/login')
    } catch {
        res.redirect('/register')
    }
    console.log(users)
})

app.delete('/logout', (req, res) => {
    req.logOut()
    res.redirect('/login')
})

function checkAuthenticated(req, res, next) {
    if (req.isAuthenticated()) {
        return next()
    }

    res.redirect('/login')
}

function checkNotAuthenticated(req, res, next){
    if (req.isAuthenticated()){
       return res.redirect('/')
    }
   return next()
}

app.listen(port, () => console.log(`SERVER app listening on port ${port}!`))